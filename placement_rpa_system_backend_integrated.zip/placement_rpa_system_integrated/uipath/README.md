# UiPath Integration Plan

The frontend now talks to the Node API when the backend is running.

## API flow

1. `GET http://localhost:5000/api/students`
2. `GET http://localhost:5000/api/applications`
3. UiPath reads the records and applies the placement rules.
4. UiPath POSTs final statuses to:
   `POST http://localhost:5000/api/uipath/callback`

Example callback JSON:

```json
{
  "applications": [
    {"id":"a1","status":"Shortlisted"},
    {"id":"a2","status":"Rejected"}
  ]
}
```

## Quick professor demo

Start backend:
`cd backend`
`npm install`
`npm start`

Open:
`http://localhost:5000`

For the first integration milestone, the frontend's **Run RPA Automation** button calls:
`POST /api/automation/run`

This is a server-side automation simulation. The next UiPath milestone is to replace that call with an actual UiPath Orchestrator job trigger or have UiPath poll/process the API and return its result through `/api/uipath/callback`.

## Recommended UiPath workflow

Sequence:
Read API/Excel → For Each Student → Validate CGPA/Backlogs → Match Company Criteria → Update Application Status → Write Result → HTTP POST callback → Generate report.

Do not put Orchestrator credentials in the frontend.
