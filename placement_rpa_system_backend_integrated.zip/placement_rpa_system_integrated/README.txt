PLACEMENT RPA - FRONTEND + BACKEND INTEGRATION

1. Install Node.js LTS.
2. Open terminal in the backend folder:
   cd backend
   npm install
   npm start
3. Open http://localhost:5000
4. Add students, companies and applications.
5. Click Run RPA Automation.
6. The browser now calls the Node API instead of relying only on localStorage.
7. API health check: http://localhost:5000/api/health

UiPath:
- uipath/README.md contains the integration contract.
- POST final UiPath results to /api/uipath/callback.
- Do NOT put UiPath/Orchestrator credentials in frontend JavaScript.

If the backend is not running, the frontend automatically falls back to its local demo data so the UI remains usable.
