const KEY = "placement_rpa_demo_v2";

const seed = {
  students: [
    {id:"s1",name:"Anjum Kaginalli",usn:"2AV23CG005",email:"anjum@example.com",branch:"CSD",cgpa:8.2,backlogs:0},
    {id:"s2",name:"Zohra",usn:"2AV23CG008",email:"zohra@example.com",branch:"CSE",cgpa:8.5,backlogs:0},
    {id:"s3",name:"Afsheen",usn:"2AV23CG009",email:"afsheen@example.com",branch:"AIML",cgpa:7.1,backlogs:1},
    {id:"s4",name:"Maryam",usn:"2AV23CG010",email:"maryam@example.com",branch:"CSD",cgpa:8.0,backlogs:0}
  ],
  companies: [
    {id:"c1",name:"Quest Global",industry:"Engineering & Technology",openings:3,roles:["Graduate Engineer","Software Engineer"]},
    {id:"c2",name:"TCS",industry:"IT Services",openings:5,roles:["Graduate Engineer Trainee","Developer"]},
    {id:"c3",name:"Infosys",industry:"Information Technology",openings:4,roles:["Software Engineer","System Engineer"]}
  ],
  applications: [
    {id:"a1",studentId:"s1",companyId:"c1",role:"Graduate Engineer",date:"2026-10-04",status:"Eligible"},
    {id:"a2",studentId:"s2",companyId:"c3",role:"Software Engineer",date:"2026-10-03",status:"Shortlisted"},
    {id:"a3",studentId:"s4",companyId:"c2",role:"Developer",date:"2026-10-02",status:"Applied"}
  ],
  lastRun:null
};

let db = loadDB();
let apiMode = false;
let currentPage = "dashboard";

async function api(path, options={}) {
  try {
    const r = await fetch(path, {headers: {"Content-Type":"application/json"}, ...options});
    if (!r.ok) throw new Error(await r.text());
    apiMode = true;
    return await r.json();
  } catch (e) {
    apiMode = false;
    return null;
  }
}

async function syncFromServer() {
  const data = await api("/api/dashboard");
  if (!data) return;
  const [students, companies, applications] = await Promise.all([
    api("/api/students"), api("/api/companies"), api("/api/applications")
  ]);
  if (students && companies && applications) {
    db.students=students; db.companies=companies; db.applications=applications;
    db.lastRun=data.lastRun; saveDB(); renderAll();
syncFromServer();
  }
}

function loadDB(){
  try { return JSON.parse(localStorage.getItem(KEY)) || structuredClone(seed); }
  catch { return structuredClone(seed); }
}
function saveDB(){ localStorage.setItem(KEY, JSON.stringify(db)); }
function uid(prefix){ return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2,6); }
function esc(v){ return String(v ?? "").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m])); }
function student(id){ return db.students.find(x=>x.id===id); }
function company(id){ return db.companies.find(x=>x.id===id); }
function eligible(s){ return Number(s.cgpa)>=7.5 && Number(s.backlogs)===0; }
function today(){ return new Date().toISOString().slice(0,10); }
function fmtDate(d){ return new Date(d+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}); }

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function toast(title,text,icon="✓"){
  $("#toastTitle").textContent=title; $("#toastText").textContent=text; $("#toastIcon").textContent=icon;
  $("#toast").classList.add("show"); clearTimeout(window.toastTimer);
  window.toastTimer=setTimeout(()=>$("#toast").classList.remove("show"),3500);
}

function navigate(page){
  currentPage=page;
  $$(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  const titles={dashboard:"Placement Dashboard",students:"Students",companies:"Companies",applications:"Applications",shortlist:"Shortlist",reports:"Reports"};
  $("#pageTitle").textContent=titles[page]||"Placement Dashboard";
  renderAll();
  if(innerWidth<900) $("#sidebar").classList.remove("open");
}

function renderAll(){
  const total=db.students.length, el=db.students.filter(eligible).length;
  const short=db.applications.filter(a=>a.status==="Shortlisted").length;
  const selected=db.applications.filter(a=>a.status==="Selected").length;
  $("#statStudents").textContent=total; $("#statCompanies").textContent=db.companies.length;
  $("#statEligible").textContent=el; $("#statShortlisted").textContent=short;
  $("#reportStudents").textContent=total; $("#reportEligible").textContent=el;
  $("#reportShortlisted").textContent=short; $("#reportSelected").textContent=selected;
  renderRecent(); renderStudents(); renderCompanies(); renderApplications(); renderShortlist(); renderReports();
}

function badge(status){
  const cls={Eligible:"eligible","Not Eligible":"rejected",Shortlisted:"shortlisted",Selected:"selected",Applied:"applied",Rejected:"rejected"}[status]||"applied";
  return `<span class="badge ${cls}">${esc(status)}</span>`;
}

function renderRecent(){
  const rows=db.applications.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
  $("#recentApplications").innerHTML=rows.length?rows.map(a=>{
    const s=student(a.studentId), c=company(a.companyId);
    return `<tr><td><b>${esc(s?.name||"Unknown")}</b><small>${esc(s?.usn||"")}</small></td><td>${esc(c?.name||"")}</td><td>${esc(a.role)}</td><td>${s?.cgpa??"-"}</td><td>${badge(a.status)}</td></tr>`;
  }).join(""):`<tr><td colspan="5" class="empty">No applications yet.</td></tr>`;
}

function renderStudents(){
  const q=($("#studentSearch")?.value||"").toLowerCase(), filter=$("#studentFilter")?.value||"all";
  const list=db.students.filter(s=>{
    const matches=(s.name+" "+s.usn+" "+s.branch).toLowerCase().includes(q);
    const st=eligible(s)?"eligible":"not";
    return matches&&(filter==="all"||st===filter);
  });
  $("#studentTableMeta").textContent=`Showing ${list.length} of ${db.students.length} candidates`;
  $("#studentsTable").innerHTML=list.length?list.map(s=>`<tr>
    <td><div class="person"><div class="person-avatar">${esc(s.name[0])}</div><div><b>${esc(s.name)}</b><small>${esc(s.email)}</small></div></div></td>
    <td>${esc(s.usn)}</td><td><span class="branch">${esc(s.branch)}</span></td><td><b>${Number(s.cgpa).toFixed(2)}</b></td><td>${s.backlogs}</td>
    <td>${badge(eligible(s)?"Eligible":"Not Eligible")}</td>
    <td><button class="icon-btn delete-student" data-id="${s.id}" title="Delete">🗑</button></td></tr>`).join(""):`<tr><td colspan="7" class="empty">No students match your search.</td></tr>`;
}

function renderCompanies(){
  $("#companiesGrid").innerHTML=db.companies.map(c=>`<div class="company-card">
    <div class="company-top"><div class="company-logo">${esc(c.name.split(" ").map(x=>x[0]).join("").slice(0,3))}</div><button class="icon-btn delete-company" data-id="${c.id}">🗑</button></div>
    <h3>${esc(c.name)}</h3><p>${esc(c.industry)}</p><div class="company-bottom"><span>● ${c.openings} Open Positions</span><small>${c.roles.length} roles</small></div>
  </div>`).join("");
}

function renderApplications(){
  const q=($("#applicationSearch")?.value||"").toLowerCase(), filter=$("#applicationFilter")?.value||"all";
  const list=db.applications.filter(a=>{
    const s=student(a.studentId),c=company(a.companyId);
    return ((s?.name+" "+c?.name+" "+a.role).toLowerCase().includes(q))&&(filter==="all"||a.status===filter);
  });
  $("#applicationsTable").innerHTML=list.length?list.map(a=>{
    const s=student(a.studentId),c=company(a.companyId);
    return `<tr><td><b>${esc(s?.name||"Unknown")}</b><small>${esc(s?.usn||"")}</small></td><td>${esc(c?.name||"")}</td><td>${esc(a.role)}</td><td>${fmtDate(a.date)}</td><td>${badge(a.status)}</td><td><select class="status-select" data-id="${a.id}">${["Applied","Eligible","Shortlisted","Selected","Rejected"].map(x=>`<option ${a.status===x?"selected":""}>${x}</option>`).join("")}</select></td></tr>`;
  }).join(""):`<tr><td colspan="6" class="empty">No applications found.</td></tr>`;
}

function renderShortlist(){
  const list=db.applications.filter(a=>a.status==="Shortlisted"||a.status==="Selected");
  $("#shortlistHeadline").textContent=`${list.length} candidate${list.length===1?"":"s"} shortlisted`;
  $("#shortlistTable").innerHTML=list.length?list.map(a=>{
    const s=student(a.studentId),c=company(a.companyId);
    return `<tr><td><div class="person"><div class="person-avatar">${esc(s?.name?.[0]||"?")}</div><div><b>${esc(s?.name||"Unknown")}</b><small>${esc(s?.usn||"")}</small></div></div></td><td>${esc(s?.branch||"")}</td><td><b>${s?.cgpa??"-"}</b></td><td>${esc(c?.name||"")}</td><td>${esc(a.role)}</td><td>${badge(a.status)}</td></tr>`;
  }).join(""):`<tr><td colspan="6" class="empty">No shortlisted candidates yet. Run the automation.</td></tr>`;
}

function renderReports(){
  const total=db.students.length, el=db.students.filter(eligible).length, not=total-el;
  const ep=total?Math.round(el/total*100):0, np=100-ep;
  $("#barEligible").style.width=ep+"%"; $("#barNotEligible").style.width=np+"%";
  $("#barEligibleText").textContent=ep+"%"; $("#barNotEligibleText").textContent=np+"%";
}

function openModal(type){
  const form=$("#modalForm"); $("#modal").classList.add("show");
  if(type==="student"){
    $("#modalEyebrow").textContent="CANDIDATE DATABASE"; $("#modalTitle").textContent="Add Student";
    form.innerHTML=`<div class="form-grid">
      <label>Student Name<input name="name" required placeholder="e.g. Rahul Kumar"></label>
      <label>USN<input name="usn" required placeholder="2AV23CS001"></label>
      <label>Email<input name="email" type="email" required placeholder="student@email.com"></label>
      <label>Branch<select name="branch"><option>CSE</option><option>CSD</option><option>AIML</option><option>ECE</option><option>EEE</option><option>ISE</option></select></label>
      <label>CGPA<input name="cgpa" type="number" min="0" max="10" step=".01" required placeholder="8.20"></label>
      <label>Backlogs<input name="backlogs" type="number" min="0" required value="0"></label>
    </div><div class="rule">Eligibility rule: <b>CGPA ≥ 7.5</b> and <b>0 backlogs</b>.</div><button class="primary full" type="submit">✓ Register Student</button>`;
  }
  if(type==="company"){
    $("#modalEyebrow").textContent="RECRUITER MANAGEMENT"; $("#modalTitle").textContent="Add Company";
    form.innerHTML=`<div class="form-grid"><label>Company Name<input name="name" required placeholder="e.g. Accenture"></label><label>Industry<input name="industry" required placeholder="IT Services"></label><label>Open Positions<input name="openings" type="number" min="1" value="1" required></label><label>Roles<input name="roles" required placeholder="Software Engineer, Analyst"></label></div><button class="primary full" type="submit">＋ Add Company</button>`;
  }
  if(type==="application"){
    $("#modalEyebrow").textContent="PLACEMENT TRACKING"; $("#modalTitle").textContent="New Application";
    form.innerHTML=`<div class="form-grid"><label>Student<select name="studentId" required>${db.students.map(s=>`<option value="${s.id}">${esc(s.name)} — ${esc(s.usn)}</option>`).join("")}</select></label><label>Company<select name="companyId" required>${db.companies.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("")}</select></label><label>Role<input name="role" required placeholder="Software Engineer"></label><label>Applied On<input name="date" type="date" value="${today()}" required></label></div><div class="rule">After adding the application, run RPA to evaluate the candidate.</div><button class="primary full" type="submit">＋ Create Application</button>`;
  }
  form.dataset.type=type;
}
function closeModal(){ $("#modal").classList.remove("show"); }

async function runAutomation(){
  const msg=$("#automationStatus"), bar=$("#progressBar");
  const btns=[$("#runAutomationBtn"),$("#runAutomationBtn2")]; btns.forEach(b=>b.disabled=true);
  const steps=[["Connecting to automation engine…",18],["Reading student records…",38],["Validating CGPA and backlogs…",58],["Generating shortlist…",78],["Updating reports…",100]];
  for(const [text,p] of steps){msg.textContent=text;bar.style.width=p+"%";await new Promise(r=>setTimeout(r,450));}
  if(apiMode){
    const result=await api("/api/automation/run",{method:"POST",body:JSON.stringify({source:"frontend-demo"})});
    if(result){
      await syncFromServer();
      msg.textContent=`✓ Server automation completed — ${result.recordsChanged} record(s) updated`;
      toast("Automation completed","Backend eligibility engine updated the shortlist.","✓");
      btns.forEach(b=>b.disabled=false); return;
    }
  }
  let created=0;
  db.applications.forEach(a=>{
    const s=student(a.studentId);
    if(!s)return;
    if(eligible(s) && (a.status==="Applied"||a.status==="Eligible")){a.status="Shortlisted";created++;}
    else if(!eligible(s) && a.status==="Applied") a.status="Rejected";
  });
  db.lastRun=new Date().toISOString(); saveDB(); renderAll();
  msg.textContent=`✓ Local automation completed — ${created} record(s) updated`;
  toast("Automation completed","Eligibility, shortlist and reports are updated.","✓");
  btns.forEach(b=>b.disabled=false);
}
function downloadCSV(){
  const rows=[["Student","USN","Branch","CGPA","Backlogs","Eligibility"]];
  db.students.forEach(s=>rows.push([s.name,s.usn,s.branch,s.cgpa,s.backlogs,eligible(s)?"Eligible":"Not Eligible"]));
  const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n");
  const blob=new Blob([csv],{type:"text/csv"}), a=document.createElement("a");
  a.href=URL.createObjectURL(blob); a.download="placement-eligibility-report.csv"; a.click(); URL.revokeObjectURL(a.href);
  toast("Report downloaded","CSV eligibility report generated.","⇩");
}

function resetDemo(){
  if(confirm("Reset all demo data to the original sample records?")){db=structuredClone(seed);saveDB();renderAll();toast("Demo reset","Original sample data restored.");}
}

document.addEventListener("click",e=>{
  const nav=e.target.closest("[data-page]"); if(nav){navigate(nav.dataset.page);return;}
  const go=e.target.closest("[data-go]"); if(go){navigate(go.dataset.go);return;}
  if(e.target.closest("#addStudentBtn"))openModal("student");
  if(e.target.closest("#addCompanyBtn"))openModal("company");
  if(e.target.closest("#addApplicationBtn"))openModal("application");
  if(e.target.closest("#closeModal"))closeModal();
  if(e.target.id==="modal")closeModal();
  if(e.target.closest("#runAutomationBtn")||e.target.closest("#runAutomationBtn2"))runAutomation();
  if(e.target.closest("#downloadReportBtn"))downloadCSV();
  if(e.target.closest("#clearStudentsBtn"))resetDemo();
  if(e.target.closest("#notifyBtn"))toast("Notifications queued","Demo email notifications prepared for shortlisted candidates.","✉");
  if(e.target.closest("#viewEligibilityReport"))toast("Eligibility report","Use Download CSV Report to export the live data.","📊");
  if(e.target.closest("#viewShortlistReport")){navigate("shortlist");toast("Shortlist report opened","Showing the current automation output.","★");}
  const delS=e.target.closest(".delete-student"); if(delS&&confirm("Delete this student and their applications?")){db.students=db.students.filter(s=>s.id!==delS.dataset.id);db.applications=db.applications.filter(a=>a.studentId!==delS.dataset.id);saveDB();renderAll();toast("Student removed","Candidate and linked applications deleted.","✓");}
  const delC=e.target.closest(".delete-company"); if(delC&&confirm("Delete this company and its applications?")){db.companies=db.companies.filter(c=>c.id!==delC.dataset.id);db.applications=db.applications.filter(a=>a.companyId!==delC.dataset.id);saveDB();renderAll();toast("Company removed","Recruiter and linked applications deleted.","✓");}
});

document.addEventListener("input",e=>{
  if(e.target.id==="studentSearch"||e.target.id==="studentFilter")renderStudents();
  if(e.target.id==="applicationSearch"||e.target.id==="applicationFilter")renderApplications();
});
document.addEventListener("change",e=>{
  if(e.target.matches(".status-select")){
    const a=db.applications.find(x=>x.id===e.target.dataset.id); if(a){a.status=e.target.value;saveDB();renderAll();toast("Status updated",`Application changed to ${a.status}.`);}
  }
});
$("#modalForm").addEventListener("submit",e=>{
  e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries()), type=e.target.dataset.type;
  if(type==="student"){
    const s={id:uid("s"),name:data.name.trim(),usn:data.usn.trim().toUpperCase(),email:data.email.trim(),branch:data.branch,cgpa:Number(data.cgpa),backlogs:Number(data.backlogs)};
    if(apiMode) {
      api("/api/students",{method:"POST",body:JSON.stringify(s)}).then(()=>syncFromServer());
    } else { db.students.push(s); saveDB(); }
    closeModal(); renderAll(); toast("Student registered",`${s.name} was added as ${eligible(s)?"Eligible":"Not Eligible"}.`);
  } else if(type==="company"){
    const c={id:uid("c"),name:data.name.trim(),industry:data.industry.trim(),openings:Number(data.openings),roles:data.roles.split(",").map(x=>x.trim()).filter(Boolean)};
    if(apiMode) api("/api/companies",{method:"POST",body:JSON.stringify(c)}).then(()=>syncFromServer()); else {db.companies.push(c);saveDB();}
    closeModal();renderAll();toast("Company added","Recruiter is now available for applications.");
  } else if(type==="application"){
    const a={id:uid("a"),studentId:data.studentId,companyId:data.companyId,role:data.role.trim(),date:data.date,status:"Applied"};
    if(apiMode) api("/api/applications",{method:"POST",body:JSON.stringify(a)}).then(()=>syncFromServer()); else {db.applications.push(a);saveDB();}
    closeModal();renderAll();toast("Application created","Run RPA Automation to evaluate it.");
  }
});

$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
window.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
renderAll();
